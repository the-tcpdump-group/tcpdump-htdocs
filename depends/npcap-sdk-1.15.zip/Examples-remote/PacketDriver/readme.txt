These files use the packet.dll API instead of wpcap.dll.
The use of packet.dll API is strongly discouraged.
