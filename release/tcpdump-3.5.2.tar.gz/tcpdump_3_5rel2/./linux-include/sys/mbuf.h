/* @(#) $Header: /tcpdump/master/tcpdump/linux-include/sys/mbuf.h,v 1.1.1.1 1999/10/07 23:47:15 mcr Exp $ (LBL) */

#ifndef MLEN
#define MLEN 128			/* needed for slcompress.h */
#endif
