/*
 * Copyright (c) 1993, 1994, 1995, 1996, 1997
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that: (1) source code distributions
 * retain the above copyright notice and this paragraph in its entirety, (2)
 * distributions including binary code include the above copyright notice and
 * this paragraph in its entirety in the documentation or other materials
 * provided with the distribution, and (3) all advertising materials mentioning
 * features or use of this software display the following acknowledgement:
 * ``This product includes software developed by the University of California,
 * Lawrence Berkeley Laboratory and its contributors.'' Neither the name of
 * the University nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior
 * written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * pcap-util.h - common code for various files
 */

#ifndef pcap_util_h
#define pcap_util_h

#include <config.h> // HAVE_xxx

#include <pcap/compiler-tests.h>
#include <pcap/pcap-inttypes.h>
/*
 * We use the "receiver-makes-right" approach to byte order;
 * because time is at a premium when we are writing the file.
 * In other words, the pcap_file_header and pcap_pkthdr,
 * records are written in host byte order.
 * Note that the bytes of packet data are written out in the order in
 * which they were received, so multi-byte fields in packets are not
 * written in host byte order, they're written in whatever order the
 * sending machine put them in.
 *
 * We also use this for fixing up packet data headers from a remote
 * capture, where the server may have a different byte order from the
 * client.
 *
 * ntoh[ls] aren't sufficient because we might need to swap on a big-endian
 * machine (if the file was written in little-end order).
 *
 * These macros are used to generate case labels in switch statements,
 * so they can't be done as inline functions, and, when passed a
 * compile-time constant argument, must produce a compile-time constant
 * result.  This means that they must either use builtin functions that
 * are recognized by the compiler as producing constant results when
 * passed a constant argument, or must be done with expressions that
 * evaluate to compile-time constants when passed a compile-time
 * constant.
 *
 * (In practical terms, to define HAVE_BUILTIN_BSWAPnn it is sufficient to
 * verify that respective builtin can be used as a case label in a switch
 * statement.)
 *
 * Newer versions of GCC, Clang, Visual Studio C/C++, and possibly
 * some other compilers recognize the expressions as byte-swapping
 * idioms and generate optimized machine-specific code for architectures
 * that include instructions that can be used to swap bytes.
 */

#if defined(__clang__) && ! PCAP_IS_AT_LEAST_CLANG_VERSION(9, 0)
/*
 * Clang releases before 9.0.0 used "unsigned long long" and "unsigned" to
 * implement __builtin_bswap64() and __builtin_bswap32() respectively, which on
 * non-mainstream architectures could work incorrectly for these and other
 * 64-bit and 32-bit builtins (see LLVM commit 0e525a4) and resulted in a
 * -Wformat on at least Linux/AMD64, where PRIx64 is defined to "lx".
 *
 * Avoid using these builtins in these Clang releases without trying to guess
 * whether the architecture is affected or not: this avoids both the warning
 * and the additional footprint that would be required in the build systems.
 * Do not undefine any macros that config.h might have defined.
 */
#define BROKEN_BUILTIN_BSWAP64
#define BROKEN_BUILTIN_BSWAP32
#endif

#if defined(HAVE_BUILTIN_BSWAP64) && ! defined(BROKEN_BUILTIN_BSWAP64)
#define PCAP_BSWAP_64(y) __builtin_bswap64((uint64_t)(y))
#else
#define PCAP_BSWAP_64(y) \
    ((uint64_t)(((((uint64_t)(y)) & UINT64_C(0xff00000000000000)) >> 56) | \
                ((((uint64_t)(y)) & UINT64_C(0x00ff000000000000)) >> 40) | \
                ((((uint64_t)(y)) & UINT64_C(0x0000ff0000000000)) >> 24) | \
                ((((uint64_t)(y)) & UINT64_C(0x000000ff00000000)) >> 8)  | \
                ((((uint64_t)(y)) & UINT64_C(0x00000000ff000000)) << 8)  | \
                ((((uint64_t)(y)) & UINT64_C(0x0000000000ff0000)) << 24) | \
                ((((uint64_t)(y)) & UINT64_C(0x000000000000ff00)) << 40) | \
                ((((uint64_t)(y)) & UINT64_C(0x00000000000000ff)) << 56)))
#endif // 64-bit

#if defined(HAVE_BUILTIN_BSWAP32) && ! defined(BROKEN_BUILTIN_BSWAP32)
#define PCAP_BSWAP_32(y) __builtin_bswap32((uint32_t)(y))
#else
#define PCAP_BSWAP_32(y) \
    ((uint32_t)(((((uint32_t)(y)) & UINT32_C(0xff000000)) >> 24) | \
                ((((uint32_t)(y)) & UINT32_C(0x00ff0000)) >> 8)  | \
                ((((uint32_t)(y)) & UINT32_C(0x0000ff00)) << 8)  | \
                ((((uint32_t)(y)) & UINT32_C(0x000000ff)) << 24)))
#endif // 32-bit

#ifdef HAVE_BUILTIN_BSWAP16
#define PCAP_BSWAP_16(y) __builtin_bswap16((uint16_t)(y))
#else
#define PCAP_BSWAP_16(y) \
    ((uint16_t)(((((uint16_t)(y)) & UINT16_C(0x00ff)) << 8) | \
                ((((uint16_t)(y)) & UINT16_C(0xff00)) >> 8)))
#endif // 16-bit

/*
 * Byte-swap a pcap_4_byte_aligned_uint64;
 */
static inline pcap_4_byte_aligned_uint64 swap_4_byte_aligned_uint64(pcap_4_byte_aligned_uint64 val)
{
	return (pcap_4_byte_aligned_uint64){.halves[0] = PCAP_BSWAP_32(val.halves[1]), .halves[1] = PCAP_BSWAP_32(val.halves[0])};
}

/*
 * Byte-swap a pcap_4_byte_aligned_int64;
 */
static inline pcap_4_byte_aligned_int64 swap_4_byte_aligned_int64(pcap_4_byte_aligned_int64 val)
{
	return (pcap_4_byte_aligned_int64){.halves[0] = PCAP_BSWAP_32(val.halves[1]), .halves[1] = PCAP_BSWAP_32(val.halves[0])};
}

extern void pcapint_post_process(int linktype, int swapped,
    struct pcap_pkthdr *hdr, u_char *data);

#endif // pcap_util_h
