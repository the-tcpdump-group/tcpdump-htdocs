# Compiling libpcap on Solaris and related OSes

* Autoconf works everywhere.
* Neither Solaris lex nor Solaris yacc are suitable.
* Neither illumos lex nor illumos yacc are suitable.
* Solaris m4 and illumos m4 are suitable.

## OmniOS r151054/AMD64

* flex 2.6.4 and GNU Bison 3.8.2 work.
* CMake 4.0.1 works.
* GCC 14.2.0 and Clang 20.1.2 work.

## Solaris CBE 11.4.90.212.0/AMD64
* flex 2.6.4 and GNU Bison 3.8.2 work.
* CMake 3.24.0 works.
* Sun C 5.15, Clang 21.1.0 and GCC 15.2.0 work.

## Solaris 11.4.72.176.1/SPARC
* flex 2.6.4 and GNU Bison 3.8.2 work.
* CMake 3.24.0 works.
* Sun C 5.15 works.
* GCC 13.2.0 and Clang 13.0.1 work, but require setting
  `PKG_CONFIG_PATH=/usr/lib/64/pkgconfig`

## Solaris 11.3/SPARC

* flex 2.6.4 and GNU Bison 3.7.5 work.
* CMake 3.14.3 works.
* Sun C 5.13, Sun C 5.14 and Sun C 5.15 work; GCC 5.5.0 and GCC 7.3.0 work.

## Solaris 10/SPARC

* libpcap build fails with rpcapd enabled.
* flex 2.6.4 and GNU Bison 3.7.5 work.
* CMake 3.14.3 works.
* Sun C 5.15 works, GCC 5.5.0 works.

## Solaris 9

This version of this OS is not supported because the snprintf(3) implementation
in its libc is not suitable.
