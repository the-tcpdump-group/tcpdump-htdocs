/*
 * Copyright (c) 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 2000
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that: (1) source code distributions
 * retain the above copyright notice and this paragraph in its entirety, (2)
 * distributions including binary code include the above copyright notice and
 * this paragraph in its entirety in the documentation or other materials
 * provided with the distribution, and (3) all advertising materials mentioning
 * features or use of this software display the following acknowledgement:
 * ``This product includes software developed by the University of California,
 * Lawrence Berkeley Laboratory and its contributors.'' Neither the name of
 * the University nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior
 * written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#include "varattrs.h"
#include "diag-control.h"

/*
 * This doesn't actually test libpcap itself; it tests whether
 * valgrind properly handles the APIs libpcap uses.  If it doesn't,
 * we end up getting patches submitted to "fix" references that
 * valgrind claims are being made to uninitialized data, when, in
 * fact, the OS isn't making any such references - or we get
 * valgrind *not* detecting *actual* incorrect references.
 *
 * Both BPF and Linux socket filters aren't handled correctly
 * by some versions of valgrind.  See valgrind bug 318203 for
 * Linux:
 *
 *	https://bugs.kde.org/show_bug.cgi?id=318203
 *
 * and valgrind bug 312989 for macOS:
 *
 *	https://bugs.kde.org/show_bug.cgi?id=312989
 *
 * The fixes for both of those are checked into the official valgrind
 * repository.
 *
 * The unofficial FreeBSD port has similar issues to the official macOS
 * port, for similar reasons.
 */
#ifndef lint
static const char copyright[] _U_ =
    "@(#) Copyright (c) 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 2000\n\
The Regents of the University of California.  All rights reserved.\n";
#endif

#include <config.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "pcap/funcattrs.h"

#include "portability.h"

#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__DragonFly__) || defined(_AIX) || defined(sun)
/* OS with BPF - use BPF */
#define USE_BPF
#elif defined(__linux__)
/* Linux - use socket filters */
#define USE_SOCKET_FILTERS
#else
#error "Unknown platform or platform that doesn't support Valgrind"
#endif

#if defined(USE_BPF)

#include <sys/ioctl.h>
#include <net/bpf.h>

/*
 * Make "pcap.h" not include "pcap/bpf.h"; we are going to include the
 * native OS version, as we're going to be doing our own ioctls to
 * make sure that, in the uninitialized-data tests, the filters aren't
 * checked by libpcap before being handed to BPF.
 */
#define PCAP_DONT_INCLUDE_PCAP_BPF_H

#elif defined(USE_SOCKET_FILTERS)

#include <sys/socket.h>
#include <linux/types.h>
#include <linux/filter.h>

#endif

/*
 * Squelch a warning.
 *
 * We include system headers to be able to directly set the filter to
 * a program with uninitialized content, to make sure what we're testing
 * is Valgrind's checking of the system call to set the filter, and we
 * also include <pcap.h> to open the device in the first place, and that
 * means that we may get collisions between their definitions of
 * BPF_STMT and BPF_JUMP - and do, in fact, get them on Linux (the
 * definitions may be semantically the same, but that's not sufficient to
 * avoid the warnings, as the preprocessor doesn't know that u_short is
 * just unsigned short).
 *
 * So we undefine BPF_STMT and BPF_JUMP to avoid the warning.
 */
#undef BPF_STMT
#undef BPF_JUMP
#include <pcap.h>

/*
 * Because test-util.h includes pcap.h, including the former before it is safe
 * to include the latter breaks things (e.g. on FreeBSD).
 */
#include "test-util.h"

static const char *program_name;

/* Forwards */
static void PCAP_NORETURN usage(void);

#define INSN_COUNT	17

int
main(int argc, char **argv)
{
	char *device;
	int op;
	int dorfmon, useactivate;
	char ebuf[PCAP_ERRBUF_SIZE];
	char *infile;
	const char *cmdbuf;
	pcap_if_t *devlist;
	pcap_t *pd;
	int status;
	int pcap_fd;
#if defined(USE_BPF)
	struct bpf_program bad_fcode;
	struct bpf_insn uninitialized[INSN_COUNT];
#elif defined(USE_SOCKET_FILTERS)
	struct sock_fprog bad_fcode;
	struct sock_filter uninitialized[INSN_COUNT];
#endif
	struct bpf_program fcode;

	device = NULL;
	dorfmon = 0;
	useactivate = 0;
	infile = NULL;
	program_name = set_program_name(argv[0]);

	opterr = 0;
	while ((op = getopt(argc, argv, "aF:i:I")) != -1) {
		switch (op) {

		case 'a':
			useactivate = 1;
			break;

		case 'F':
			infile = optarg;
			break;

		case 'i':
			device = optarg;
			break;

		case 'I':
			dorfmon = 1;
			useactivate = 1;	/* required for rfmon */
			break;

		default:
			usage();
			/* NOTREACHED */
		}
	}

	if (device == NULL) {
		/*
		 * No interface specified; get whatever pcap_lookupdev()
		 * finds.
		 */
		if (pcap_findalldevs(&devlist, ebuf) == -1)
			error(EX_OSERR, "%s", ebuf);
		if (devlist == NULL)
			error(EX_UNAVAILABLE,
			    "no interfaces available for capture");
		device = strdup(devlist->name);
		pcap_freealldevs(devlist);
	}

	if (infile != NULL) {
		/*
		 * Filter specified with "-F" and a file containing
		 * a filter.
		 */
		cmdbuf = read_infile(infile);
	} else {
		if (optind < argc) {
			/*
			 * Filter specified with arguments on the
			 * command line.
			 */
			cmdbuf = copy_argv(&argv[optind+1]);
		} else {
			/*
			 * No filter specified; use an empty string, which
			 * compiles to an "accept all" filter.
			 */
			cmdbuf = "";
		}
	}

	if (useactivate) {
		pd = pcap_create(device, ebuf);
		if (pd == NULL)
			error(EX_OSERR, "%s: pcap_create() failed: %s",
			    device, ebuf);
		status = pcap_set_snaplen(pd, 65535);
		if (status != 0)
			error(EX_OSERR, "%s: pcap_set_snaplen failed: %s",
			    device, pcap_statustostr(status));
		status = pcap_set_promisc(pd, 1);
		if (status != 0)
			error(EX_OSERR, "%s: pcap_set_promisc failed: %s",
			    device, pcap_statustostr(status));
		if (dorfmon) {
			status = pcap_set_rfmon(pd, 1);
			if (status != 0)
				error(EX_OSERR, "%s: pcap_set_rfmon failed: %s",
				    device, pcap_statustostr(status));
		}
		status = pcap_set_timeout(pd, 1000);
		if (status != 0)
			error(EX_OSERR, "%s: pcap_set_timeout failed: %s",
			    device, pcap_statustostr(status));
		status = pcap_activate(pd);
		if (status < 0) {
			/*
			 * pcap_activate() failed.
			 */
			error(EX_OSERR, "%s: %s\n(%s)", device,
			    pcap_statustostr(status), pcap_geterr(pd));
		} else if (status > 0) {
			/*
			 * pcap_activate() succeeded, but it's warning us
			 * of a problem it had.
			 */
			warning("%s: %s\n(%s)", device,
			    pcap_statustostr(status), pcap_geterr(pd));
		}
	} else {
		*ebuf = '\0';
		pd = pcap_open_live(device, 65535, 1, 1000, ebuf);
		if (pd == NULL)
			error(EX_OSERR, "%s", ebuf);
		else if (*ebuf)
			warning("%s", ebuf);
	}

	pcap_fd = pcap_fileno(pd);

	/*
	 * Try setting a filter with an uninitialized bpf_program
	 * structure.  This should cause valgrind to report a
	 * problem.
	 *
	 * We don't check for errors, because it could get an
	 * error due to a bad pointer or count.
	 */
#if defined(USE_BPF)
	ioctl(pcap_fd, BIOCSETF, &bad_fcode);
#elif defined(USE_SOCKET_FILTERS)
	/*
	 * The point of this test is not to initialize bad_fcode, as we're
	 * testing to make sure that valgrind will complain that the structure
	 * isn't initialized.
	 */
DIAG_OFF_UNINITIALIZED_CONST_POINTER
	setsockopt(pcap_fd, SOL_SOCKET, SO_ATTACH_FILTER, &bad_fcode,
	    sizeof(bad_fcode));
DIAG_ON_UNINITIALIZED_CONST_POINTER
#endif

	/*
	 * Try setting a filter with an initialized bpf_program
	 * structure that points to an uninitialized program.
	 * That should also cause valgrind to report a problem.
	 *
	 * We don't check for errors, because it could get an
	 * error due to a bad pointer or count.
	 */
#if defined(USE_BPF)
	bad_fcode.bf_len = INSN_COUNT;
	bad_fcode.bf_insns = uninitialized;
	ioctl(pcap_fd, BIOCSETF, &bad_fcode);
#elif defined(USE_SOCKET_FILTERS)
	bad_fcode.len = INSN_COUNT;
	bad_fcode.filter = uninitialized;
	setsockopt(pcap_fd, SOL_SOCKET, SO_ATTACH_FILTER, &bad_fcode,
	    sizeof(bad_fcode));
#endif

	/*
	 * Now compile a filter and set the filter with that.
	 * That should *not* cause valgrind to report a
	 * problem.
	 */
	if (pcap_compile(pd, &fcode, cmdbuf, 1, 0) < 0)
		error(EX_DATAERR, "can't compile filter: %s", pcap_geterr(pd));
	if (pcap_setfilter(pd, &fcode) < 0)
		error(EX_OSERR, "can't set filter: %s", pcap_geterr(pd));

	pcap_close(pd);
	exit(EX_OK);
}

static void
usage(void)
{
	(void)fprintf(stderr, "%s, with %s\n", program_name,
	    pcap_lib_version());
	(void)fprintf(stderr,
	    "Usage: %s [-aI] [ -F file ] [ -i interface ] [ expression ]\n",
	    program_name);
	exit(EX_USAGE);
}
